from ultralytics import YOLO
import cv2

# Load trained model
model = YOLO("runs/detect/train10/weights/best.pt")

# Load video file
cap = cv2.VideoCapture("D:/Python Project/Volo_vesion/gun_test_new_Trim.mp4")

while True:
    ret, frame = cap.read()
    if not ret:
        break

    # Resize frame to match training image size
    frame_resized = cv2.resize(frame, (640, 640))

    # Predict with low confidence threshold
    results = model.predict(source=frame_resized, save=False, show=False, conf=0.1)

    # Draw results
    annotated = results[0].plot()

    # Show on screen
    cv2.imshow("Detection", annotated)

    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

cap.release()
cv2.destroyAllWindows()
