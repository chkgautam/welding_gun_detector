import os

def check_yolo_labels(label_folder):
    valid = True
    for filename in os.listdir(label_folder):
        if not filename.endswith('.txt'):
            continue
        filepath = os.path.join(label_folder, filename)
        with open(filepath, 'r') as f:
            lines = f.readlines()
            for i, line in enumerate(lines):
                parts = line.strip().split()
                if len(parts) != 5:
                    print(f"[❌ ERROR] {filename} line {i+1}: Incorrect number of elements")
                    valid = False
                    continue
                try:
                    cls = int(parts[0])
                    if cls not in [0, 1]:
                        print(f"[❌ ERROR] {filename} line {i+1}: Invalid class ID {cls}")
                        valid = False

                    values = list(map(float, parts[1:]))
                    for v in values:
                        if v < 0.0 or v > 1.0:
                            print(f"[❌ ERROR] {filename} line {i+1}: Value out of range [0–1] → {v}")
                            valid = False
                except ValueError:
                    print(f"[❌ ERROR] {filename} line {i+1}: Non-numeric value found")
                    valid = False

    if valid:
        print("✅ All YOLO label files are correctly formatted.")
    else:
        print("⚠️ Some files have issues. Please check the above errors.")

# 🔁 Run this with your actual labels folder path
check_yolo_labels("d:/Python Project/welding_gun_detector/data/labels")

